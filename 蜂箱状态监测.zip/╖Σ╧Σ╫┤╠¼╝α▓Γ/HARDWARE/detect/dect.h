#ifndef    DETECT_H
#define     DETECT_H
#include   "sys.h"

void Detect_Read(void);
void get_voit_d(void);
void get_voit_g(void );
void chaoshengbo(void);
void Dht11_read(void);


#endif